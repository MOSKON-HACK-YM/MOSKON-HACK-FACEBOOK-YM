++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
╔═╦═╗╔═╗╔══╗╔╦╗╔═╗╔═╦╗
║║║║║║║║║══╣║╔╝║║║║║║║
║║║║║║║║╠══║║╚╗║║║║║║║
╚╩═╩╝╚═╝╚══╝╚╩╝╚═╝╚╩═╝
──────────────────────
  WhatsApp> +967715801806
  by : MOSKON
 Yamani Scorpion Organisation
Telegram:t.me/xomhg31
https://www.youtube.com/channel/UCrDpucyeuECBfVPXrdav6xw
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
$pkg update
$pkg upgrade
$pkg install python
$pkg install python2
$pkg upgrade
$pkg install git
$pkg install pip
$pkg install pip2
$pip upgrade
$pip2 install requests
$pip2 install mechanize
$git clone https://github.com/MOSKON-HACK-YM/MOSKON-HACK-FACEBOOK-YM
$cd MOSKON-HACK-FACEBOOK-YM
$unzip MOSKON-HACK-FACEBOOK.zip
$rm -rif MOSKON-HACK-FACEBOOK.zip
$cd MOSKON-HACK-FACEBOOK
$chmod +x MOSKON-HACK-FACEBOOK
$python2 MOSKON-HACK-FACEBOOK